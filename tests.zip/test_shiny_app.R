# ==============================================================================
# AIRGUARD 360: Automated Verification Suite
# File: tests/test_shiny_app.R
# Purpose: Test Shiny app syntax, object creation, and module loading
# ==============================================================================

message(">> [TEST SUITE] Validating AIRGUARD 360 Shiny Application...")

# Source app and check app object
app_obj <- tryCatch({
  # Load app into a separate environment to check UI & Server
  source("app.R", local = TRUE)$value
}, error = function(e) {
  stop("FATAL: app.R failed to load: ", conditionMessage(e))
})

stopifnot(shiny::is.shiny.appobj(app_obj))
message("   [PASS] app.R successfully compiled into valid Shiny App object.")

# Check required processed data files
required_files <- c(
  "data/airguard.sqlite",
  "data/processed/airguard_clean.rds",
  "data/processed/airguard_enriched.rds",
  "outputs/tables/pollutant_summary_stats.csv",
  "outputs/tables/correlation_matrix.csv",
  "outputs/tables/hotspot_vulnerability_ranking.csv",
  "outputs/tables/hypothesis_tests_summary.rds"
)

for (f in required_files) {
  if (!file.exists(f)) {
    stop("Missing required artifact: ", f)
  }
}
message("   [PASS] All 7 processed data and statistical artifacts exist on disk.")

message(">> [TEST SUITE] 100% Tests Passed Successfully.")
