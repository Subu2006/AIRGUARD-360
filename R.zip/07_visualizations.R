# ==============================================================================
# AIRGUARD 360: Environmental Intelligence & Decision-Support System
# File: R/07_visualizations.R
# Purpose: Comprehensive Basic & Advanced Visualizations (ggplot2 & Plotly)
# INT232 Syllabus Mapping: Unit VI (Basic: Scatter, Line, Bar, Pie/Donut;
#                                  Advanced: Heat Map, Bollinger Bands; Plotly)
# ==============================================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(plotly)
  library(dplyr)
  library(scales)
})

# Source theme if not already in environment
if (!exists("theme_airguard")) {
  source("R/00_config.R")
}

# ------------------------------------------------------------------------------
# 1. Basic Visualizations: Temporal Trend Line Chart
# ------------------------------------------------------------------------------
plot_temporal_trend <- function(df, target_city = "Delhi", target_var = "PM2.5", 
                                start_date = NULL, end_date = NULL, interactive = TRUE) {
  sub_df <- df %>% filter(City == target_city)
  
  if (!is.null(start_date)) sub_df <- sub_df %>% filter(Date >= as.Date(start_date))
  if (!is.null(end_date))   sub_df <- sub_df %>% filter(Date <= as.Date(end_date))
  
  if (nrow(sub_df) == 0) return(NULL)
  
  limit_val <- NAAQS_LIMITS[[target_var]]
  
  p <- ggplot(sub_df, aes(x = Date, y = .data[[target_var]])) +
    geom_line(color = "#94A3B8", alpha = 0.5, linewidth = 0.5) +
    geom_line(aes(y = .data[[paste0(target_var, "_MA7")]]), color = THEME_COLORS$primary, linewidth = 1.0) +
    labs(
      title = sprintf("%s Concentration Trajectory: %s", target_var, target_city),
      subtitle = "Grey: Raw Daily Readings | Blue: 7-Day Moving Average | Red Dashed: NAAQS 24-hr Standard",
      x = "Date", y = sprintf("%s Concentration (ug/m3)", target_var)
    ) +
    theme_airguard()
  
  if (!is.null(limit_val)) {
    p <- p + geom_hline(yintercept = limit_val, color = THEME_COLORS$danger, linetype = "dashed", linewidth = 0.8)
  }
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y"))
  } else {
    p
  }
}

# ------------------------------------------------------------------------------
# 2. Basic Visualizations: Bar Chart of Location Rankings (Hotspots)
# ------------------------------------------------------------------------------
plot_city_rankings <- function(df, target_var = "AQI", top_n = 10, interactive = TRUE) {
  ranking_df <- df %>%
    group_by(City) %>%
    summarise(Mean_Val = mean(.data[[target_var]], na.rm = TRUE), .groups = "drop") %>%
    filter(!is.na(Mean_Val)) %>%
    arrange(desc(Mean_Val)) %>%
    slice_head(n = top_n) %>%
    mutate(City = factor(City, levels = rev(City)))
  
  p <- ggplot(ranking_df, aes(x = Mean_Val, y = City, fill = Mean_Val)) +
    geom_col(width = 0.7, show.legend = FALSE) +
    scale_fill_gradient(low = "#FFD166", high = "#EF476F") +
    geom_text(aes(label = round(Mean_Val, 1)), hjust = -0.15, size = 3.5, fontface = "bold") +
    labs(
      title = sprintf("Top %d Hotspots by Mean %s (2015-2020)", top_n, target_var),
      x = sprintf("Mean %s", target_var), y = ""
    ) +
    theme_airguard() +
    theme(panel.grid.major.y = element_blank())
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y"))
  } else {
    p
  }
}

# ------------------------------------------------------------------------------
# 3. Basic Visualizations: Stoichiometric Scatter Plot (PM2.5 vs PM10)
# ------------------------------------------------------------------------------
plot_pollutant_scatter <- function(df, target_city = "Delhi", var_x = "PM10", var_y = "PM2.5", interactive = TRUE) {
  sub_df <- df %>% filter(City == target_city, !is.na(.data[[var_x]]), !is.na(.data[[var_y]]))
  
  if (nrow(sub_df) == 0) return(NULL)
  
  p <- ggplot(sub_df, aes(x = .data[[var_x]], y = .data[[var_y]], color = Season)) +
    geom_point(alpha = 0.6, size = 2) +
    geom_smooth(method = "lm", color = "#1E293B", linetype = "solid", se = TRUE) +
    scale_color_brewer(palette = "Set1") +
    labs(
      title = sprintf("Particulate Stoichiometry: %s vs %s (%s)", var_y, var_x, target_city),
      subtitle = "Fitted Linear Regression demonstrates shared emission and meteorological sources",
      x = sprintf("%s (ug/m3)", var_x), y = sprintf("%s (ug/m3)", var_y)
    ) +
    theme_airguard()
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y", "color"))
  } else {
    p
  }
}

# ------------------------------------------------------------------------------
# 4. Basic Visualizations: Donut Chart of CPCB AQI Buckets
# ------------------------------------------------------------------------------
plot_aqi_donut <- function(df, target_city = "Delhi") {
  sub_df <- df %>% filter(City == target_city, !is.na(AQI_Bucket))
  
  if (nrow(sub_df) == 0) return(NULL)
  
  cat_counts <- sub_df %>%
    count(AQI_Bucket) %>%
    mutate(
      Percentage = round((n / sum(n)) * 100, 1),
      Color = AQI_COLOR_MAP[as.character(AQI_Bucket)]
    )
  
  plot_ly(
    cat_counts,
    labels = ~AQI_Bucket,
    values = ~n,
    type = "pie",
    hole = 0.6,
    textinfo = "label+percent",
    marker = list(colors = ~Color),
    hoverinfo = "text",
    text = ~paste(AQI_Bucket, "<br>Days:", n, "<br>Share:", Percentage, "%")
  ) %>%
    layout(
      title = list(text = sprintf("<b>AQI Severity Distribution: %s</b>", target_city), font = list(size = 14)),
      showlegend = TRUE,
      margin = list(t = 40, b = 20, l = 20, r = 20)
    )
}

# ------------------------------------------------------------------------------
# 5. Advanced Visualizations: Correlation Heat Map (Unit VI)
# ------------------------------------------------------------------------------
plot_correlation_heatmap <- function(cor_matrix, interactive = TRUE) {
  cor_df <- as.data.frame(as.table(cor_matrix))
  colnames(cor_df) <- c("Pollutant1", "Pollutant2", "Correlation")
  
  p <- ggplot(cor_df, aes(x = Pollutant1, y = Pollutant2, fill = Correlation)) +
    geom_tile(color = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%.2f", Correlation)), color = "black", size = 3.5, fontface = "bold") +
    scale_fill_gradient2(low = "#3B82F6", mid = "#F8FAFC", high = "#EF4444", midpoint = 0, limit = c(-1, 1)) +
    labs(
      title = "Multi-Pollutant Pearson Correlation Matrix",
      subtitle = "Values indicate degree of collinearity and shared chemical transport",
      x = "", y = ""
    ) +
    theme_airguard() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y", "fill"))
  } else {
    p
  }
}

# ------------------------------------------------------------------------------
# 6. Advanced Visualizations: Bollinger Bands on Air Quality Volatility (Unit VI)
# ------------------------------------------------------------------------------
plot_bollinger_bands <- function(df, target_city = "Delhi", start_date = NULL, end_date = NULL, interactive = TRUE) {
  sub_df <- df %>% filter(City == target_city, !is.na(PM2.5), !is.na(PM2.5_BB_Upper))
  
  if (!is.null(start_date)) sub_df <- sub_df %>% filter(Date >= as.Date(start_date))
  if (!is.null(end_date))   sub_df <- sub_df %>% filter(Date <= as.Date(end_date))
  
  if (nrow(sub_df) == 0) return(NULL)
  
  p <- ggplot(sub_df, aes(x = Date)) +
    # Volatility Envelope Ribbon
    geom_ribbon(aes(ymin = PM2.5_BB_Lower, ymax = PM2.5_BB_Upper), fill = "#93C5FD", alpha = 0.3) +
    # 20-Day Moving Average
    geom_line(aes(y = PM2.5_BB_Mid), color = "#2563EB", linewidth = 0.9, linetype = "solid") +
    # Upper Band
    geom_line(aes(y = PM2.5_BB_Upper), color = "#EF4444", linewidth = 0.6, linetype = "dashed") +
    # Lower Band
    geom_line(aes(y = PM2.5_BB_Lower), color = "#10B981", linewidth = 0.6, linetype = "dashed") +
    # Actual PM2.5
    geom_line(aes(y = PM2.5), color = "#1E293B", linewidth = 0.5, alpha = 0.6) +
    # Highlight Volatility Spikes
    geom_point(data = sub_df %>% filter(PM2.5_Bollinger_Spike == 1),
               aes(y = PM2.5), color = "#DC2626", size = 2) +
    labs(
      title = sprintf("PM2.5 Volatility Bands (Bollinger Metric): %s", target_city),
      subtitle = "Blue: 20-Day MA | Red Dashed: Upper Band (+2 SD) | Green: Lower Band | Red Dots: Anomaly Surges",
      x = "Date", y = "PM2.5 Concentration (ug/m3)"
    ) +
    theme_airguard()
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y"))
  } else {
    p
  }
}

# ------------------------------------------------------------------------------
# 7. Advanced Visualizations: Predictive Forecast Ribbon Plot (CO5)
# ------------------------------------------------------------------------------
plot_forecast_chart <- function(forecast_res, interactive = TRUE) {
  if (is.null(forecast_res)) return(NULL)
  
  fc_data <- forecast_res$data
  city    <- forecast_res$city
  var     <- forecast_res$variable
  model   <- forecast_res$metrics$Model_Selected
  
  p <- ggplot(fc_data, aes(x = Date, y = Forecast)) +
    # 95% Interval Ribbon
    geom_ribbon(data = fc_data %>% filter(Type == "Forecast"),
                aes(ymin = Lower_95, ymax = Upper_95), fill = "#CBD5E1", alpha = 0.6) +
    # 80% Interval Ribbon
    geom_ribbon(data = fc_data %>% filter(Type == "Forecast"),
                aes(ymin = Lower_80, ymax = Upper_80), fill = "#93C5FD", alpha = 0.6) +
    # Main Trajectory Line
    geom_line(aes(color = Type), linewidth = 1.0) +
    scale_color_manual(values = c("Observed" = "#1E293B", "Forecast" = "#2563EB")) +
    labs(
      title = sprintf("30-Day %s Predictive Forecast: %s (Model: %s)", var, city, model),
      subtitle = "Dark Ribbon: 80% Prediction Interval | Light Ribbon: 95% Interval",
      x = "Date", y = sprintf("%s Concentration", var)
    ) +
    theme_airguard()
  
  if (interactive) {
    ggplotly(p, tooltip = c("x", "y", "color"))
  } else {
    p
  }
}
