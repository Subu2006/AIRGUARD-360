# ==============================================================================
# AIRGUARD 360: Environmental Intelligence & Decision-Support System
# File: R/02_data_cleaning.R
# Purpose: Rigorous Data Cleaning, Missing Data Auditing, and Normalization
# INT232 Syllabus Mapping: Unit II (Data Frames, Factors), Unit IV (dplyr, tidyr, pipe, handling missing data)
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(lubridate)
})

#' Clean and Preprocess Raw Environmental Data
#' 
#' @param raw_data List returned by initialize_data_pipeline() or loaded from disk
#' @param output_dir Path to save clean processed RDS files
#' @return A list containing cleaned station-level and city-level data frames
clean_airguard_data <- function(raw_data, output_dir = "data/processed") {
  message(">> [AIRGUARD 360] Executing Data Cleaning and Preprocessing...")
  
  df_st_day  <- raw_data$station_day
  df_stations<- raw_data$stations
  
  # ----------------------------------------------------------------------------
  # Step 1: Schema Standardisation & Type Coercion
  # ----------------------------------------------------------------------------
  pollutant_cols <- c("PM2.5", "PM10", "NO", "NO2", "NOx", "NH3", "CO", 
                      "SO2", "O3", "Benzene", "Toluene", "Xylene", "AQI")
  
  # Ensure all numeric columns are strictly numeric
  for (col in pollutant_cols) {
    df_st_day[[col]] <- suppressWarnings(as.numeric(df_st_day[[col]]))
    # Physical Sanity Check: Ambient concentrations cannot be negative.
    # Replace sensor calibration negative anomalies with NA
    df_st_day[[col]][!is.na(df_st_day[[col]]) & df_st_day[[col]] < 0] <- NA
  }
  
  # Parse dates safely
  df_st_day$Date <- as.Date(df_st_day$Date)
  
  # ----------------------------------------------------------------------------
  # Step 2: Relational Join with Spatial Dimension (Unit II & Unit IV)
  # ----------------------------------------------------------------------------
  message("   Joining fact table with station geographic dimension...")
  df_joined <- df_st_day %>%
    left_join(
      df_stations %>% select(StationId, StationName, City, State, Status),
      by = "StationId"
    )
  
  # ----------------------------------------------------------------------------
  # Step 3: AQI Bucket Imputation and Factor Encoding (Unit II: Factors)
  # ----------------------------------------------------------------------------
  # CPCB Official AQI Categories
  bucket_levels <- c("Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe")
  
  # If AQI exists but AQI_Bucket is NA, impute bucket based on statutory breakpoints
  df_joined <- df_joined %>%
    mutate(
      AQI_Bucket_Clean = case_when(
        !is.na(AQI_Bucket) & AQI_Bucket %in% bucket_levels ~ AQI_Bucket,
        !is.na(AQI) & AQI <= 50  ~ "Good",
        !is.na(AQI) & AQI <= 100 ~ "Satisfactory",
        !is.na(AQI) & AQI <= 200 ~ "Moderate",
        !is.na(AQI) & AQI <= 300 ~ "Poor",
        !is.na(AQI) & AQI <= 400 ~ "Very Poor",
        !is.na(AQI) & AQI > 400  ~ "Severe",
        TRUE ~ NA_character_
      ),
      AQI_Bucket = factor(AQI_Bucket_Clean, levels = bucket_levels, ordered = TRUE),
      City = as.factor(City),
      State = as.factor(State)
    ) %>%
    select(-AQI_Bucket_Clean)
  
  # ----------------------------------------------------------------------------
  # Step 4: Missing Data Quality Audit (INT232 Practical 9: Data Wrangling)
  # ----------------------------------------------------------------------------
  total_records <- nrow(df_joined)
  missing_summary <- sapply(df_joined, function(x) sum(is.na(x)))
  missing_pct <- round((missing_summary / total_records) * 100, 2)
  
  missing_audit_df <- data.frame(
    Variable = names(missing_summary),
    Missing_Count = missing_summary,
    Missing_Percentage = missing_pct,
    stringsAsFactors = FALSE
  )
  
  message("   Data Cleaning Audit Completed:")
  message(sprintf("   - Total Valid Rows: %d", total_records))
  message(sprintf("   - Mean AQI Missingness: %.1f%%", missing_pct["AQI"]))
  message(sprintf("   - Mean PM2.5 Missingness: %.1f%%", missing_pct["PM2.5"]))
  
  # ----------------------------------------------------------------------------
  # Step 5: City-Level Daily Aggregate (Unit IV: dplyr group_by & summarise)
  # High-performance roll-up across multi-station cities for smooth dashboarding
  # ----------------------------------------------------------------------------
  message("   Computing City-level daily aggregates across monitoring stations...")
  df_city_daily <- df_joined %>%
    filter(!is.na(City) & City != "") %>%
    group_by(City, State, Date) %>%
    summarise(
      Active_Stations = n_distinct(StationId[!is.na(AQI) | !is.na(PM2.5)]),
      PM2.5 = if (all(is.na(PM2.5))) NA_real_ else mean(PM2.5, na.rm = TRUE),
      PM10  = if (all(is.na(PM10)))  NA_real_ else mean(PM10, na.rm = TRUE),
      NO2   = if (all(is.na(NO2)))   NA_real_ else mean(NO2, na.rm = TRUE),
      SO2   = if (all(is.na(SO2)))   NA_real_ else mean(SO2, na.rm = TRUE),
      CO    = if (all(is.na(CO)))    NA_real_ else mean(CO, na.rm = TRUE),
      O3    = if (all(is.na(O3)))    NA_real_ else mean(O3, na.rm = TRUE),
      NH3   = if (all(is.na(NH3)))   NA_real_ else mean(NH3, na.rm = TRUE),
      AQI   = if (all(is.na(AQI)))   NA_real_ else mean(AQI, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      AQI = round(AQI, 1),
      PM2.5 = round(PM2.5, 1),
      PM10 = round(PM10, 1),
      AQI_Bucket = case_when(
        !is.na(AQI) & AQI <= 50  ~ "Good",
        !is.na(AQI) & AQI <= 100 ~ "Satisfactory",
        !is.na(AQI) & AQI <= 200 ~ "Moderate",
        !is.na(AQI) & AQI <= 300 ~ "Poor",
        !is.na(AQI) & AQI <= 400 ~ "Very Poor",
        !is.na(AQI) & AQI > 400  ~ "Severe",
        TRUE ~ NA_character_
      ),
      AQI_Bucket = factor(AQI_Bucket, levels = bucket_levels, ordered = TRUE)
    )
  
  # ----------------------------------------------------------------------------
  # Step 6: Save Processed RDS Artifacts
  # ----------------------------------------------------------------------------
  dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
  saveRDS(df_joined, file.path(output_dir, "airguard_clean.rds"))
  saveRDS(df_city_daily, file.path(output_dir, "airguard_city_daily.rds"))
  saveRDS(missing_audit_df, file.path(output_dir, "data_quality_audit.rds"))
  
  message(sprintf(">> [AIRGUARD 360] Cleaned datasets saved to %s", output_dir))
  
  return(list(
    station_clean = df_joined,
    city_daily    = df_city_daily,
    audit         = missing_audit_df
  ))
}
